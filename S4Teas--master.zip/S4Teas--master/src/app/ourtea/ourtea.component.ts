
import { Component } from '@angular/core';
@Component({
  selector: 'app-ourtea',
  templateUrl: './ourtea.component.html',
  styleUrl: './ourtea.component.css'
})
export class OurteaComponent {
 
}
