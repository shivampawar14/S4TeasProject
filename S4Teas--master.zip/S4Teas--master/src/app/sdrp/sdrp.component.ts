import { Component } from '@angular/core';

@Component({
  selector: 'app-sdrp',
  templateUrl: './sdrp.component.html',
  styleUrl: './sdrp.component.css'
})
export class SdrpComponent {

}
