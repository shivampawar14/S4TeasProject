import { Component } from '@angular/core';

@Component({
  selector: 'app-tandc',
  templateUrl: './tandc.component.html',
  styleUrl: './tandc.component.css'
})
export class TandcComponent {

}
